import rubpy


class RejectRequestOwner:
    async def reject_request_owner(
        self: 'rubpy.Client',
        object_guid: str
        ):
            input_data = {
                'action': 'Reject',
                'object_guid': object_guid
                
            }
            return await self.builder(
                name='replyRequestObjectOwner',
                input=input_data
            )