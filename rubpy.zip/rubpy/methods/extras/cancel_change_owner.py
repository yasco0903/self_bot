import rubpy


class CancelChangeObjectOwner:
    async def cancel_change_owner(
        self: 'rubpy.Client',
        object_guid: str
        ):
            return await self.builder(name='cancelChangeObjectOwner', input= {'object_guid': object_guid})