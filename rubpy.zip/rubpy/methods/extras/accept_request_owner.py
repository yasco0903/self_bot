import rubpy


class AcceptRequestObjectOwner:
    async def accept_request_owner(
        self: 'rubpy.Client',
        object_guid: str
        ):
            
            input_data= {
                "action": 'Accept',  # Accept Reject
                "object_guid": object_guid
                }
                
            return await self.builder(name='replyRequestObjectOwner', input=input_data)