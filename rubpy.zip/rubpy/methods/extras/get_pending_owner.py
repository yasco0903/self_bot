import rubpy


class GetPendingObjectOwner:
    async def get_pending_owner(
        self: 'rubpy.Client',
        object_guid: str,
        ):
            
            return self.builder(
                name='getPendingObjectOwner',
                input={'object_guid': object_guid}
                )