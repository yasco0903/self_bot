import rubpy

class RequestsChangeOwner:
    async def request_change_owner(
        self: 'rubpy.Client',
        object_guid: str,
        member_guid: str,
        ):
            
            input_data= {
                'new_owner_user_guid': member_guid,
                'object_guid': object_guid
                }
                
            return self.builder(
                name='requestChangeObjectOwner',
                input=input_data
                )