from .on_message_updates import OnMessageUpdates
from .on_remove_notifications import OnRemoveNotifications
from .on_show_notifications import OnShowNotifications
from .on_chat_updates import OnChatUpdates
from .on_show_activities import OnShowActivities
from .on_unconfirmed_session_updates import OnUnconfirmedSessionUpdates
from .on_group_voice_chat_participant_updates import OnGroupVoiceChatParticipantUpdates
from .on_group_voice_chat_updates import OnGroupVoiceChatUpdates
from .on_call_updates import OnCallUpdates
from .on_call_signal_data import OnCallSignalData

class Decorators(
    OnMessageUpdates,
    OnChatUpdates,
    OnRemoveNotifications,
    OnShowActivities,
    OnShowNotifications,
    OnUnconfirmedSessionUpdates,
    OnGroupVoiceChatParticipantUpdates,
    OnGroupVoiceChatUpdates,
    OnCallUpdates,
    OnCallSignalData
):
    pass