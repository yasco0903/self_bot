import rubpy
from ... import handlers

class OnCallSignalData:
    def on_call_signal_data(
            self: "rubpy.Client",
            *args, **kwargs,
    ):
        def MetaHandler(func):
            """
            Decorator to register a function as a handler for call signal data.

            Args:
                func: The function to be registered as a handler.

            Returns:
                func: The original function.
            """
            self.add_handler(func, handlers.CallSignalData(*args, **kwargs))
            return func
        return MetaHandler
        