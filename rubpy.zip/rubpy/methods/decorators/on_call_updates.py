import rubpy
from ... import handlers

class OnCallUpdates:
    def on_call_updates(
            self: "rubpy.Client",
            *args, **kwargs,
    ):
        def MetaHandler(func):
            """
            Decorator to register a function as a handler for call updates.

            Args:
                func: The function to be registered as a handler.

            Returns:
                func: The original function.
            """
            self.add_handler(func, handlers.CallUpdates(*args, **kwargs))
            return func
        return MetaHandler
        