import rubpy
from ... import handlers

class OnUnconfirmedSessionUpdates:
    def on_unconfirmed_session_updates(
            self: "rubpy.Client",
            *args, **kwargs,
    ):
        def MetaHandler(func):
            """
            Decorator to register a function as a handler for un confirmed sesion updates.

            Args:
                func: The function to be registered as a handler.

            Returns:
                func: The original function.
            """
            self.add_handler(func, handlers.UnconfirmedSessionUpdates(*args, **kwargs))
            return func
        return MetaHandler
        