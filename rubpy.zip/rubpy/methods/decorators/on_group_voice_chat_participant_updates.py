import rubpy
from ... import handlers

class OnGroupVoiceChatParticipantUpdates:
    def on_group_voice_chat_participant_updates(
            self: "rubpy.Client",
            *args, **kwargs,
    ):
        def MetaHandler(func):
            """
            Decorator to register a function as a handler for group voice chat participant updates.

            Args:
                func: The function to be registered as a handler.

            Returns:
                func: The original function.
            """
            
            self.add_handler(func, handlers.GroupVoiceChatParticipantUpdates(*args, **kwargs))
            return func
        return MetaHandler
        