import rubpy

class TerminateOtherSessions:
    async def terminate_other_sessions(self: 'rubpy.Client'):
        
        return await self.builder(name='terminateOtherSessions')