import rubpy

class SetSetting:
    """
    Provides a method to set various privacy settings for the user.

    Methods:
    - set_setting: Set various privacy settings for the user.

    Attributes:
    - self (rubpy.Client): The rubpy client instance.
    """

    async def set_setting(
            self: "rubpy.Client",
            show_my_last_online: bool = None,
            show_my_phone_number: bool = None,
            show_my_profile_photo: bool = None,
            show_my_birth_date: bool = None,
            delete_account_not_active: int = None,
            link_forward_message: bool = None,
            can_join_chat_by: bool = None,
            can_caled_by: bool = None,
            
    ) -> rubpy.types.Update:
        """
        Set various privacy settings for the user.

        Parameters:
        - show_my_last_online (Optional[str]): Privacy setting for showing last online status.
        - show_my_phone_number (Optional[str]): Privacy setting for showing phone number.
        - show_my_profile_photo (Optional[str]): Privacy setting for showing profile photo.
        - link_forward_message (Optional[str]): Privacy setting for link forwarding messages.
        - can_join_chat_by (Optional[str]): Privacy setting for who can join chats.

        Returns:
        - rubpy.types.Update: The updated privacy settings.
        """
        input = {
            'settings': {},
            "update_parameters": []
        }

        if show_my_last_online is not None:
            input['settings']["show_my_last_online"] = "Everybody" if show_my_last_online else "Nobody"
            input["update_parameters"].append("show_my_last_online")

        if show_my_phone_number is not None:
            input["settings"]["show_my_phone_number"] = "Everybody" if show_my_phone_number else "Nobody"
            input["update_parameters"].append("show_my_phone_number")

        if show_my_profile_photo is not None:
            input["settings"]["show_my_profile_photo"] = "Everybody" if show_my_profile_photo else "MyContacts"
            input["update_parameters"].append("show_my_profile_photo")

        if link_forward_message is not None:
            input["settings"]["link_forward_message"] = "Everybody" if link_forward_message else "Nobody"
            input["update_parameters"].append("link_forward_message")

        if can_caled_by is not None:
            input['settings']['can_called_by'] = 'Everybody' if can_caled_by else 'Nobody'
            input["update_parameters"].append('can_called_by')
            
        if show_my_birth_date is not None:
            input['settings']['show_my_birth_date'] = 'Everybody' if show_my_birth_date else 'MyContacts'
            input["update_parameters"].append('show_my_birth_date')
            
        if delete_account_not_active is not None and isinstance(delete_account_not_active, int):
            input['settings']['delete_account_not_active_months'] = delete_account_not_active
            input["update_parameters"].append('delete_account_not_active_months')
        if can_join_chat_by is not None:
            input["settings"]["can_join_chat_by"] = "Everybody" if can_join_chat_by else "MyContacts"
            input["update_parameters"].append("can_join_chat_by")

        
        

        return await self.builder(name='setSetting', input=input)  # type: ignore
