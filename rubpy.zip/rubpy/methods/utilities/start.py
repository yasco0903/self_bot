from ... import exceptions
from ...crypto import Crypto
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
import rubpy
import re

def convert_farsi_digits(text):
    return text.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789"))

def normalize_phone_number(phone: str) -> str | None:
    phone = convert_farsi_digits(phone)
    phone = phone.strip().replace(" ", "").replace("-", "").replace("(", "").replace(")", "")

    # پترن کامل: تشخیص شماره داخلی و بین‌المللی (تا ۱۵ رقم طبق استاندارد ITU-T E.164)
    pattern = re.compile(r"^(?:\+|00)?(\d{7,15})$")

    match = pattern.match(phone)
    if match:
        return match.group(1) if phone.startswith("00") else f"{match.group(1)}"
    return None

class Start:
    async def start(self: "rubpy.Client", phone_number: str = None):
        """
        Start the RubPy client, handling user registration if necessary.

        Args:
        - phone_number (str): The phone number to use for starting the client.

        Returns:
        - The initialized client.
        """
        if not hasattr(self, 'connection'):
            await self.connect()

        try:
            self.decode_auth = Crypto.decode_auth(self.auth) if self.auth is not None else None
            self.import_key = pkcs1_15.new(RSA.import_key(self.private_key.encode())) if self.private_key is not None else None
            result = await self.get_me()
            self.guid = result.user.user_guid
            self.logger.info('user', extra={'guid': result})

        except exceptions.NotRegistered:
            self.logger.debug('user not registered!')
            print("》Hi My friend")
            if True:
                while True:
                    phone_number = input('\n» Enter the phone number: ')

                    phone_number = normalize_phone_number(phone_number)
                    phone_number = f'98{phone_number[1:]}' if phone_number.startswith('0') else phone_number
                    print("» ["+phone_number+"]")
                    try:
                        result = await self.send_code(phone_number=phone_number, send_type='SMS')
                        break
                    except Exception as e:
                        print(f"» The phone number is invalid! Please try again.!: {e}")
                        continue

            if result.status == 'SendPassKey':
                while True:
                    pass_key = input(f'\n» Enter the Password [{result.hint_pass_key}] :  ')
                    try:
                        result = await self.send_code(phone_number=phone_number, pass_key=pass_key)
                    except Exception as e:
                        pass
                        

                    if result.status != 'OK':
                        print(f"» The pass key({result.hint_pass_key}) is invalid! Please try again.!")
                        continue
                    else:
                        break

            public_key, self.private_key = Crypto.create_keys()
            while True:
                phone_code = input('\n» Enter the code: ')

                result = await self.sign_in(
                    phone_code=phone_code,
                    phone_number=phone_number,
                    phone_code_hash=result.phone_code_hash,
                    public_key=public_key)

                if result.status != 'OK':
                    print(f"» The code is invalid! Please try again.!")
                    continue
                else:
                    result.auth = Crypto.decrypt_RSA_OAEP(self.private_key, result.auth)
                    self.key = Crypto.passphrase(result.auth)
                    self.auth = result.auth
                    self.decode_auth = Crypto.decode_auth(self.auth)
                    self.import_key = pkcs1_15.new(RSA.import_key(self.private_key.encode())) if self.private_key is not None else None
                    self.session.insert(
                        auth=self.auth,
                        guid=result.user.user_guid,
                        user_agent=self.user_agent,
                        phone_number=result.user.phone,
                        private_key=self.private_key)

                    await self.register_device(device_model=self.name)
                    print(f"\n» Sign in as 《\"{self.name}\" 》was successful.")
                    break

        return self