import rubpy


class GetChatVoiceChatParticipants:
    async def get_voice_chat_participants(
          self: 'rubpy.Client',
          object_guid: str, 
          voice_chat_id: str,
          ):
          
          
          
          chat_type = 'Group' if object_guid.startswith('g0') else 'Channel'
          
          input_data = {
                 f"{chat_type.lower()}_guid": object_guid,
                "voice_chat_id": voice_chat_id,
                 }
                 
          return await self.builder(
            name=f"get{chat_type}VoiceChatParticipants", 
            input=input_data)