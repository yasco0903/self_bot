import rubpy
import random
from io import BytesIO
from base64 import b64encode
from os import system
class SENDLIVE:
    async def send_live(
       self: 'rubpy.Client',
       object_guid: str,
       thumbinline: str
        ):
            if isinstance(thumbinline, bytes):
                thumb_data = thumbinline
                
            else:
                with open(thumbinline, 'rb') as f:
                    thumb_data = f.read()
                    
           
            
            def getImageThumbnail(bytes:bytes) -> str:
                try:
                    from PIL import Image
                except ImportError:
                    system("pip install pillow")
                    from PIL import Image
            
                image = Image.open(BytesIO(bytes))
                width, height = image.size
                if height > width:
                    new_height = 40
                    new_width  = round(new_height * width / height)
                else:
                    new_width = 40
                    new_height = round(new_width * height / width)
                image = image.resize((new_width, new_height), Image.LANCZOS)
                changed_image = BytesIO()
                image.save(changed_image, format="PNG")
                return b64encode(changed_image.getvalue()).decode("UTF-8")
            
            
            method="sendLive",
            input={
                "thumb_inline": getImageThumbnail(thumb_data),
                "device_type": "Software",
                "object_guid": object_guid,
                "rnd": random.randint(-9999, 9999)
            }
        
            return await self.builder(name=method, input=input)