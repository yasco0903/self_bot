import rubpy



class RequestCall:
    async def request_call(
    self: 'rubpy.Client',
    chat_guid: str,
    call_type: str
    ):
        input_data = {"call_type": call_type,
                "library_versions": ["2.7.7", "2.4.4"],
                "max_layer": 92,
                "min_layer": 65,
                "sip_version": 1,
                "support_call_out": True,
                "user_guid": chat_guid}
        
        
        return await self.builder(name='requestCall', input=input_data)