import rubpy


class DiscardCall:
    async def discard_call(
    self: 'rubpy.Client',
    call_id: str,
    duration: int,
    reason: str
    ):
        
        input_data = {"call_id": call_id,
                "duration": duration,
                "reason": reason  # Missed OR Disconnect
                }
        
        
        return await self.builder(name='discardCall', input=input_data)