import rubpy
from rubpy.types import Update

class DeleteAvatar:
    async def delete_avatar(
            self: "rubpy.Client",
            object_guid: str,
            avatar_id: str,
    ) -> Update:
        """
        Delete an avatar.

        Parameters:
        - object_guid (str): The unique identifier of the object (e.g., user, chat) that owns the avatar.
        - avatar_id (str): The identifier of the avatar to be deleted.

        Returns:
        rubpy.types.Update: The result of the API call.
        
        Note:
            - If `object_guid` is 'me', 'cloud', or 'self', it will be replaced with the client's GUID.
        """
        
        if object_guid.lower() in ['me', 'cloud', 'self']:
            object_guid = self.guid
            
        return await self.builder('deleteAvatar',
                                  input={
                                      'object_guid': object_guid,
                                      'avatar_id': avatar_id,
                                  })
