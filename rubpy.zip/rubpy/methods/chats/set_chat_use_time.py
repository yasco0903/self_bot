import rubpy


class SetChatUseTime:
    async def set_chat_use_time(
        self: 'rubpy.Client',
        object_guid: str,
        time: int
        ):
            
            return await self.builder(name='setChatUseTime', input={'object_guid': object_guid, 'time': time})