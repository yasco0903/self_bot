import rubpy
import random

class SendContact:
    async def send_contact(
    self: 'rubpy.Client',
    object_guid: str,
    first_name: str,
    last_name: str , 
    phone_number: str,
    user_guid: str,
    message_id: str
    ):
        input_data = {"message_contact": {
                    "first_name": first_name,
                    "last_name": last_name or "",
                    "phone_number": phone_number,
                    "user_guid": user_guid
                },
                "object_guid": object_guid,
                "rnd": str(random.randint(-99999999, 99999999)),
                "reply_to_message_id": message_id}
        
        
        
        return await self.builder(name='sendMessage', input=input_data)
        