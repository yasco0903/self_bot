import asyncio
import sys
from typing import Type, List, Dict, Any, Optional
from .types import Update

# لیست handlerهای مجاز
AUTHORIZED_HANDLERS = [
    'ChatUpdates',
    'MessageUpdates',
    'ShowActivities',
    'ShowNotifications',
    'RemoveNotifications',
    'UnconfirmedSessionUpdates',
    'GroupVoiceChatParticipantUpdates',
    'GroupVoiceChatUpdates',
    'CallUpdates',
    'CallSignalData'
]

def create_handler(
    name: str,
    base: tuple,
    authorized_handlers: List[str] = AUTHORIZED_HANDLERS,
    exception: bool = True,
    **kwargs
) -> Optional[Type['BaseHandlers']]:
    """
    ایجاد دینامیک یک handler بر اساس نام و کلاس پایه.
    """
    if name in authorized_handlers:
        return type(name, base, {'__name__': name, **kwargs})
    
    if not exception:
        return None
    
    raise AttributeError(f"ماژول فاقد handler با نام '{name}' است")

class BaseHandlers(Update):
    """
    کلاس پایه برای handlerهای سفارشی.
    """
    __name__ = 'CustomHandlers'

    def __init__(self, *models: Any, any_handler: bool = False, **kwargs) -> None:
        self.__models = models
        self.__any_handler = any_handler

    def is_async(self, value: Any) -> bool:
        """
        بررسی اینکه آیا تابع داده‌شده ناهمگام (async) است.
        """
        return asyncio.iscoroutinefunction(value) or (hasattr(value, '__call__') and asyncio.iscoroutinefunction(value.__call__))

    async def __call__(self, update: Dict, *args, **kwargs) -> bool:
        """
        اجرای handler روی آپدیت داده‌شده.
        """
        self.original_update = update

        if not self.__models:
            return True

        for handler_filter in self.__models:
            # اگر handler_filter یک کلاس باشد، نمونه‌سازی می‌شود
            filter_instance = handler_filter(func=None) if isinstance(handler_filter, type) else handler_filter
            # بررسی ناهمگام یا همگام بودن فیلتر و اجرای آن
            status = await filter_instance(self, result=None) if self.is_async(filter_instance) else filter_instance(self, result=None)

            if status and self.__any_handler:
                return True
            if not status:
                return False

        return True

class Handlers:
    """
    کلاس برای مدیریت و ایجاد handlerهای خاص.
    """
    def __init__(self, name: str) -> None:
        self.__name__ = name

    def __eq__(self, value: object) -> bool:
        return BaseHandlers in getattr(value, '__bases__', ())

    def __dir__(self) -> List[str]:
        return sorted(AUTHORIZED_HANDLERS)

    def __call__(self, name: str, *args, **kwargs) -> Type['BaseHandlers']:
        return self.__getattr__(name)(*args, **kwargs)

    def __getattr__(self, name: str) -> Type['BaseHandlers']:
        return create_handler(name, (BaseHandlers,), AUTHORIZED_HANDLERS)

    def __repr__(self) -> str:
        return f"<module 'rubpy.handlers' from '...'>"

# ایجاد نمونه‌های از پیش تعریف شده برای دات نوتیشن
_current_module = sys.modules[__name__]
_handler_instance = Handlers(__name__)
sys.modules[__name__] = _handler_instance

# تعریف صریح attributeها برای دات نوتیشن
for handler_name in AUTHORIZED_HANDLERS:
    setattr(_handler_instance, handler_name, create_handler(handler_name, (BaseHandlers,)))